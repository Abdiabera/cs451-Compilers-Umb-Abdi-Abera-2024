-->Name: Abdi Abera
-->Instructor : Ethan Cerami
-->Subject : csc 287
-->Date: 10/30/2021

			project 1


This video game is a kind of simple game to play.
If we click "ok" button the aliens fly to up by the pointer degree means if you click "ok" button on the staight top of the aliens , then the aliens moving up staright. If you click "ok" button from the Alien to around 65 degree then it goes 65 degree. while they are flying, if we enter "Enter key" then the aliens stop on the air and if we click "ok" button then it hits the block or the ground. 
we can use other trick if we want finish and  play the game quickly, we can just click ok button as we can and the aliens breaks the block. when the game end. It show us "Y" or "N" when we complete the game. If we click "Y" then it continues if "N" then it stops.



Thank you for playing